import { Logger } from "../../utils/logger.js";
const homePage = async function (req,res) 
{
    Logger.info("GET Request");
    return res.render('homepage');   
}


export {homePage}